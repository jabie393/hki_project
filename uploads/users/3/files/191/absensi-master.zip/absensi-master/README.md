# absensi

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.


![Screenshot_2022-01-20-15-06-02-506_com ronaldi absensi 1](https://user-images.githubusercontent.com/56151166/150298315-f212b48a-468f-43f8-bc2f-4d54bd04f9f7.jpg)
![Screenshot_2022-01-20-15-06-05-445_com ronaldi absensi 1](https://user-images.githubusercontent.com/56151166/150298452-205e27d4-13b6-4201-90e3-807faaa0043b.jpg)
![Screenshot_2022-01-20-15-06-12-743_com ronaldi absensi 1](https://user-images.githubusercontent.com/56151166/150298551-0149019a-58a3-4ca8-b170-d3d51f75947b.jpg)
![Screenshot_2022-01-20-15-06-19-910_com ronaldi absensi 1](https://user-images.githubusercontent.com/56151166/150298645-768d5abf-d7d3-4480-85fb-8f650ee41a72.jpg)
